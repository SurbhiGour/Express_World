<?php
include"dbinfo.php";

if(isset($_GET['dc_id'])){
	$result=mysql_query("DELETE FROM `report` WHERE `id`='".$_GET['dc_id']."'")or die(mysql_error());
	if($result)
	header("location:admin_display.php");
}
?>