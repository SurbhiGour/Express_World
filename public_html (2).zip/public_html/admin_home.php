<?php  include("header_admin.php");?>
<section id="intro">

    <div id="intro-carousel"  >
   <div class="item" style="background-image: url('img/tr.jpg');height: 45vh;"></div>
  
    </div>


  </section>
<div class="admin-baner">
  <div class="wrap-content-header">
    <div class="gridabout">
      <h2 style="color:white">Admin Panel</h2>
    </div>
  </div>
</div>
<style>
.headtag{
	    font-weight: bold;
    font-size: 2.5em;
    color: #0160a4;
    box-shadow: 1px 1px 10px #53c5cf;
    width: 50%;
    height: 91px;
    position: relative;
    top: -74px;
        padding: 21px;
    /*padding: 500px 1px 90px 1px;*/
}
</style>

<center><p class="headtag" >Welcome to Admin Pannel</p> </center>

</div>
</div>
<?php include("footer.php")?>
