<?php  include("header_admin.php");?>
<script src="//code.jquery.com/jquery-1.12.4.js"></script>

<script src="//cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="//cdn.rawgit.com/bpampuch/pdfmake/0.1.27/build/pdfmake.min.js"></script>
<script src="//cdn.rawgit.com/bpampuch/pdfmake/0.1.27/build/vfs_fonts.js"></script>

<link rel="stylesheet" type="text/css" href="datatables/media/css/jquery.dataTables.min.css">    <link rel="stylesheet" type="text/css" href="datatables/media/css/dataTables.bootstrap.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/dt/jq-2.1.4,jszip-2.5.0,pdfmake-0.1.18,dt-1.10.9,af-2.0.0,b-1.0.3,b-colvis-1.0.3,b-html5-1.0.3,b-print-1.0.3,se-1.0.1/datatables.min.css"/>
<!-- <script>
$(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            {
                exportOptions: {
                 columns: ':contains("Office")'
                }
            },
            'excelHtml5',
        ]
    } );
} );
</script> -->
<style>
.col{
		float:left;
		width: 20%;
		padding: 5px 25px 5px 5px;
	}
</style>

<?php include ("dbinfo.php");  ?>
<center>
<div class="container"style="background: aliceblue;height: auto;">
<form id="contact3" action="" method="post" enctype="multipart/form-data" style="height: auto;" >
<h3 style="position: relative;right: 36px;color: #094f9d;font-size: 30px;"><b>Display Tracking Detail</b></h3><br>
<fieldset>
	<div class="col">
		<label>Select Date Range</label>
    </div>
	<div class="col">
      <input id="setdate" type="date" class="form-control" name="txt_issue" placeholder="Issue Date" required>
    </div>
	<div class="col">
      <input id="setdate" type="date" class="form-control" name="txt_due" placeholder="Due Date" required>
    </div>
	<div class="col">
      <button name="btn_view" type="submit" id="contact-submit" data-submit="...Sending">View</button>
    </div>
</fieldset>
<hr>
<div style="overflow-x: scroll;overflow-y: scroll;height: auto;">
    <table width="100%" id="example" class="display">
	<thead>
            <tr style="background-color:#c9e1ec;">
              <th>ID</th> 
			  <th>AWB No</th> 
              <th>Date</th>  
			  <th>Shipper</th>	
			  <th>Receiver</th>
              <th>Weight</th>
			  <th>Destination</th> 
			  <th>Connection</th>				  
			  <th>TrackNo</th>  
			  <th>Record Date</th>
			  <th>Edit</th> 
			  <th>Delete</th> 
            </tr>
			</thead>
			<tbody>
            <?php 

			if(isset($_POST['btn_view']))
			{
				$issue=$_POST['txt_issue'];
				$due=$_POST['txt_due'];
				$qry=mysql_query("SELECT * FROM `report` WHERE record_date >= '$issue' AND record_date <= '$due'")or die(mysql_error());
			}else{
				$qry=mysql_query("SELECT * FROM `report` WHERE record_date = CURDATE()")or die(mysql_error());
			}
				$count=1;
				while($row=mysql_fetch_array($qry))
			{?>
            <tr>
              <td><?php echo $count++;?></td>
              <td><?php echo $row['airway_bno'];?></td>
			  <td><?php echo $row['date'];?></td>
              <td><?php echo $row['shipper'];?></td>
			  <td><?php echo $row['carrier'];?></td>
			  <td><?php echo $row['weight'];?></td>
			  <td><?php echo $row['destination'];?></td>
			  <td><?php echo $row['connection'];?></td>
			  <td><?php echo $row['trackno'];?></td>
			  <td><?php echo $row['record_date'];?></td>
			  <td><?php echo "<a href='admin_add.php?temp_id=".$row['id']."'><i class='fa fa-edit fa-fw'></i></a>"; ?> </td>
			  <td><?php echo "<a href='delete_code.php?dc_id=".$row['id']."' onClick=\"javascript:return confirm('are you sure you want to delete this?');\"><i class='fa fa-times fa-fw'></i></a>"; ?></td>
            </tr>
            <?php }?>
			</tbody>
    </table>
</div>		
</form>

</div>
</center>
<?php include("footer.php")?>

<script type="text/javascript" src="datatables/media/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="datatables/media/js/dataTables.bootstrap.min.js"></script>


 <script type="text/javascript" src="https://cdn.datatables.net/r/dt/jq-2.1.4,jszip-2.5.0,pdfmake-0.1.18,dt-1.10.9,af-2.0.0,b-1.0.3,b-colvis-1.0.3,b-html5-1.0.3,b-print-1.0.3,se-1.0.1/datatables.min.js"> </script>
    
<script type="text/javascript">
  $(document).ready(function() {
   
          $('#example').DataTable({

"lengthMenu": [ 5, 10, 20, 50, 100 ],

              "scrollX": true,
              "dom": 'lBfrtip',
              "buttons": [
                            {
                            
                              extend: 'excelHtml5',
                              text: '<i class="fa fa-file-excel-o"></i>',
                              titleAttr: 'Excel'
                             
                            },     
                         ]
 
   
  });
$("[data-toggle=tooltip]").tooltip();
 
var table=$('#example').DataTable();

      table
      .order([[0,'desc']])
      .draw(false);

  });
</script>

