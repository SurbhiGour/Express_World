<?php 
include "header.php"; 
 ?>
 <section id="intro">

    <div id="intro-carousel" class="owl-carousel" >
   <div class="item" style="background-image: url('img/blog.jpg');"></div>
  <!--    <div class="item" style="background-image: url('img/intro-carousel/2.jpg');"></div>
      <div class="item" style="background-image: url('img/intro-carousel/3.jpg');"></div>
      <div class="item" style="background-image: url('img/intro-carousel/4.jpg');"></div>
      <div class="item" style="background-image: url('img/intro-carousel/5.jpg');"></div> -->
    </div>


  </section><!-- #intro -->
 <?php 
include "footer.php"; 
 ?>