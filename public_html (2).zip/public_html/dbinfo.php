<?php

$con=mysql_connect("localhost","expressw_expres","express@123");

$conn=mysql_select_db("expressw_express_track_db",$con);  

?> 